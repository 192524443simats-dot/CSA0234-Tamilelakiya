import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Crosshair,
  ShieldAlert,
  Unlink,
} from 'lucide-react';
import { MemoryCell, MemoryStatus, PointerLink } from '../types/memory';

interface MemoryVisualizerProps {
  cells: MemoryCell[];
  pointers: PointerLink[];
  status: MemoryStatus;
  interactive?: boolean;
  selectedAddress?: string | null;
  correctAddress?: string | null;
  revealResult?: boolean;
  onSelectCell?: (cell: MemoryCell) => void;
  title?: string;
}

const STATUS_CONFIG: Record<
  MemoryStatus,
  {
    bg: string;
    border: string;
    text: string;
    icon: React.ReactNode;
  }
> = {
  STABLE: {
    bg: 'bg-[#10E784]/12',
    border: 'border-[#10E784]/45',
    text: 'text-[#10E784]',
    icon: <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />,
  },
  'NULL POINTER': {
    bg: 'bg-[#FFB800]/14',
    border: 'border-[#FFB800]/50',
    text: 'text-[#FFB800]',
    icon: <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />,
  },
  DANGLING: {
    bg: 'bg-[#FFB800]/14',
    border: 'border-[#FFB800]/50',
    text: 'text-[#FFB800]',
    icon: <Unlink className="h-3.5 w-3.5" aria-hidden="true" />,
  },
  LEAK: {
    bg: 'bg-[#FFB800]/14',
    border: 'border-[#FFB800]/50',
    text: 'text-[#FFB800]',
    icon: <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />,
  },
  SEGFAULT: {
    bg: 'bg-[#FF5A79]/15',
    border: 'border-[#FF5A79]/60',
    text: 'text-[#FFB4AB]',
    icon: <ShieldAlert className="h-3.5 w-3.5" aria-hidden="true" />,
  },
};

export const MemoryVisualizer: React.FC<MemoryVisualizerProps> = ({
  cells,
  pointers,
  status,
  interactive = false,
  selectedAddress = null,
  correctAddress = null,
  revealResult = false,
  onSelectCell,
  title = 'Register & Memory Bank',
}) => {
  const stackCells = cells.filter((c) => c.segment === 'stack');
  const heapCells = cells.filter((c) => c.segment === 'heap');
  const statusStyle = STATUS_CONFIG[status];

  const renderCellGroup = (groupCells: MemoryCell[], segmentTitle: string) => {
    if (groupCells.length === 0) return null;

    return (
      <div className="space-y-2.5">
        <div className="flex items-center justify-between text-xs text-[#968DA1]">
          <span className="font-mono font-semibold tracking-wider text-[#CDC2D8]">
            {segmentTitle}
          </span>
          <span className="font-mono">
            {groupCells.reduce((acc, c) => acc + c.bytes, 0)} bytes mapped
          </span>
        </div>

        {/* Horizontal connected register bank with sharp internal dividers */}
        <div className="overflow-x-auto pb-1">
          <div className="inline-flex min-w-full rounded-lg border border-white/12 bg-[#0A0E1A] overflow-hidden">
            {groupCells.map((cell) => {
              const incomingPointers = pointers.filter(
                (p) => p.targetAddress === cell.address
              );
              const isTargeted = incomingPointers.length > 0;
              const isDanglingTarget = incomingPointers.some((p) => p.isDangling);
              const isSelected = selectedAddress === cell.address;
              const isCorrectReveal =
                revealResult && correctAddress === cell.address;
              const isWrongReveal =
                revealResult && isSelected && correctAddress !== cell.address;

              let cellRing = '';
              if (isCorrectReveal) {
                cellRing =
                  'bg-[#10E784]/14 ring-2 ring-inset ring-[#10E784] shadow-[inset_0_0_20px_rgba(16,231,132,0.28)]';
              } else if (isWrongReveal || cell.isFault) {
                cellRing =
                  'bg-[#FF5A79]/14 ring-2 ring-inset ring-[#FF5A79] shadow-[inset_0_0_20px_rgba(255,90,121,0.28)]';
              } else if (isSelected) {
                cellRing =
                  'bg-[#8A3FFC]/18 ring-2 ring-inset ring-[#8A3FFC] shadow-[inset_0_0_18px_rgba(138,63,252,0.3)]';
              } else if (isDanglingTarget) {
                cellRing =
                  'bg-[#FFB800]/10 ring-1 ring-inset ring-[#FFB800]/70';
              } else if (isTargeted) {
                cellRing =
                  'bg-[#00F0FF]/10 ring-1 ring-inset ring-[#00F0FF]/70 shadow-[inset_0_0_20px_rgba(0,240,255,0.22)]';
              } else if (cell.isMutated) {
                cellRing = 'bg-[#8A3FFC]/12';
              } else if (cell.isRead) {
                cellRing = 'bg-[#00F0FF]/8';
              } else if (!cell.isAllocated) {
                cellRing = 'bg-[#080B14]/70 opacity-75';
              }

              const Tag = interactive ? 'button' : 'div';

              return (
                <Tag
                  key={cell.address}
                  type={interactive ? 'button' : undefined}
                  onClick={
                    interactive && onSelectCell
                      ? () => onSelectCell(cell)
                      : undefined
                  }
                  className={`group relative flex min-w-[136px] flex-1 flex-col border-r border-white/10 last:border-r-0 text-left transition-colors ${cellRing} ${
                    interactive
                      ? 'cursor-pointer hover:bg-[#182035]/90 focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-[#00F0FF]'
                      : ''
                  }`}
                >
                  {/* Vertical Cyan / Amber Laser Indicator */}
                  {isTargeted && (
                    <div
                      aria-hidden="true"
                      className={`flex flex-col items-center pt-1.5 ${
                        isDanglingTarget ? 'text-[#FFB800]' : 'text-[#00F0FF]'
                      }`}
                    >
                      <span className="font-mono text-[10px] font-semibold tracking-wider px-1.5 py-0.5 rounded bg-[#080B14]/90 border border-current">
                        {incomingPointers.map((p) => `*${p.name}`).join(' · ')}
                      </span>
                      <span
                        className={`h-3.5 w-[2px] ${
                          isDanglingTarget
                            ? 'bg-[#FFB800] shadow-[0_0_10px_#FFB800]'
                            : 'bg-[#00F0FF] shadow-[0_0_12px_#00F0FF]'
                        }`}
                      />
                    </div>
                  )}

                  {/* Top Address & Offset Header */}
                  <div
                    className={`flex items-center justify-between gap-2 border-b border-white/8 bg-[#101524]/80 px-3 py-2 ${
                      isTargeted ? 'mt-0' : ''
                    }`}
                  >
                    <span className="font-mono text-[11px] font-semibold text-[#00F0FF]">
                      {cell.offsetLabel}
                    </span>
                    <span className="font-mono text-[11px] text-[#968DA1]">
                      {cell.address}
                    </span>
                  </div>

                  {/* Register Value Slot */}
                  <div className="flex flex-1 flex-col justify-between gap-2 px-3 py-3.5">
                    <div className="flex items-center justify-between gap-1.5">
                      <span className="font-mono text-xs font-semibold text-[#CDC2D8] truncate">
                        {cell.label || 'unused'}
                      </span>
                      <span className="font-mono text-[11px] text-[#968DA1]">
                        {cell.typeName}
                      </span>
                    </div>

                    <div
                      className={`font-mono text-lg font-bold tracking-tight ${
                        cell.isFault
                          ? 'text-[#FFB4AB]'
                          : cell.isFreed
                          ? 'text-[#FFB800]'
                          : cell.isMutated
                          ? 'text-[#D4BBFF]'
                          : isTargeted
                          ? 'text-[#D3FBFF]'
                          : cell.isAllocated
                          ? 'text-[#E0E2EF]'
                          : 'text-[#4B4455]'
                      }`}
                    >
                      {cell.value}
                    </div>

                    <div className="flex items-center justify-between text-[11px] font-mono text-[#968DA1]">
                      <span>{cell.bytes}B slot</span>
                      {interactive && (
                        <span className="inline-flex items-center gap-1 text-[#00F0FF] opacity-0 group-hover:opacity-100 transition-opacity">
                          <Crosshair className="h-3 w-3" aria-hidden="true" />
                          Target
                        </span>
                      )}
                    </div>
                  </div>
                </Tag>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  return (
    <section
      aria-label={title}
      className="rounded-2xl border border-white/8 bg-[#101524] p-4 sm:p-5 space-y-4"
    >
      {/* Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-display text-base sm:text-lg font-semibold text-[#E0E2EF]">
            {title}
          </h3>
          <p className="text-xs text-[#968DA1]">
            {interactive
              ? 'Select a memory cell directly in the register bank below.'
              : 'Live hexadecimal byte slots and active pointer laser targets.'}
          </p>
        </div>

        {/* Semantic Status Pill */}
        <div
          className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 font-mono text-xs font-semibold whitespace-nowrap ${statusStyle.bg} ${statusStyle.border} ${statusStyle.text}`}
        >
          {statusStyle.icon}
          <span>{status}</span>
        </div>
      </div>

      {/* Active Pointer Bus Strip */}
      {pointers.length > 0 && (
        <div className="flex flex-wrap items-center gap-3 rounded-lg border border-white/8 bg-[#182035] px-3.5 py-2.5">
          <span className="font-mono text-xs font-semibold text-[#968DA1]">
            Active Pointers:
          </span>
          {pointers.map((ptr) => {
            const isNull = ptr.targetAddress === null;
            return (
              <div
                key={`${ptr.name}-${ptr.sourceAddress}`}
                className="inline-flex items-center gap-2 font-mono text-xs"
              >
                <span className="font-semibold text-[#D4BBFF]">{ptr.name}</span>
                <span className="text-[#968DA1]">({ptr.sourceAddress})</span>
                <span className="text-[#00F0FF]" aria-hidden="true">
                  →
                </span>
                <span
                  className={
                    isNull
                      ? 'font-semibold text-[#FFB4AB]'
                      : ptr.isDangling
                      ? 'font-semibold text-[#FFB800]'
                      : 'font-semibold text-[#00F0FF]'
                  }
                >
                  {isNull ? '0x0000 (NULL)' : ptr.targetAddress}
                </span>
                {ptr.label && (
                  <span className="text-[#968DA1]">· {ptr.label}</span>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Register Segments */}
      <div className="space-y-5">
        {renderCellGroup(stackCells, 'Stack Frame (Automatic Scope)')}
        {renderCellGroup(heapCells, 'Heap Arena (Dynamic Allocation)')}
      </div>
    </section>
  );
};
