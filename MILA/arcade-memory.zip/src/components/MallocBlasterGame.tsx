import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Heart,
  Pause,
  Play,
  RotateCcw,
  Shield,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import { GameState } from '../types/memory';
import { arcadeAudio } from '../utils/arcadeAudio';
import { ArtworkImage } from './ArtworkImage';

interface MallocBlasterGameProps {
  highScore: number;
  onScoreSubmit: (score: number, xpGain: number) => void;
}

interface Laser {
  x: number;
  y: number;
  vy: number;
  isEnemy?: boolean;
}

interface Enemy {
  x: number;
  y: number;
  w: number;
  h: number;
  hp: number;
  maxHp: number;
  label: string;
  color: string;
  points: number;
}

interface PowerUp {
  x: number;
  y: number;
  kind: 'dual' | 'shield';
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  r: number;
}

interface Star {
  x: number;
  y: number;
  speed: number;
  size: number;
}

const CANVAS_W = 640;
const CANVAS_H = 460;

export const MallocBlasterGame: React.FC<MallocBlasterGameProps> = ({
  highScore,
  onScoreSubmit,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [gameState, setGameState] = useState<GameState>('TITLE_MENU');
  const [score, setScore] = useState(0);
  const [wave, setWave] = useState(1);
  const [lives, setLives] = useState(3);
  const [dualFire, setDualFire] = useState(false);
  const [hasShield, setHasShield] = useState(false);
  const [autoFire, setAutoFire] = useState(true);
  const [muted, setMuted] = useState(arcadeAudio.muted);

  const shipXRef = useRef(CANVAS_W / 2);
  const keysRef = useRef<{ left: boolean; right: boolean; fire: boolean }>({
    left: false,
    right: false,
    fire: false,
  });
  const lasersRef = useRef<Laser[]>([]);
  const enemiesRef = useRef<Enemy[]>([]);
  const enemyDirRef = useRef(1);
  const powerUpsRef = useRef<PowerUp[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const starsRef = useRef<Star[]>(
    Array.from({ length: 55 }, () => ({
      x: Math.random() * CANVAS_W,
      y: Math.random() * CANVAS_H,
      speed: 0.5 + Math.random() * 1.8,
      size: 1 + Math.random() * 1.6,
    }))
  );
  const scoreRef = useRef(0);
  const waveRef = useRef(1);
  const livesRef = useRef(3);
  const dualUntilRef = useRef(0);
  const shieldRef = useRef(false);
  const autoFireRef = useRef(true);
  const lastShotRef = useRef(0);
  const shakeRef = useRef(0);
  const stateRef = useRef<GameState>('TITLE_MENU');
  const animRef = useRef<number | null>(null);

  useEffect(() => {
    stateRef.current = gameState;
  }, [gameState]);

  useEffect(() => {
    autoFireRef.current = autoFire;
  }, [autoFire]);

  const spawnWave = useCallback((waveNum: number) => {
    const list: Enemy[] = [];
    const rows = Math.min(4, 2 + Math.floor(waveNum / 2));
    const cols = 7;
    const labels = ['LEAK', 'NULL', 'DANGLING', 'OVERFLOW'];
    const colors = ['#FF5A79', '#FFB800', '#A56EFF', '#00F0FF'];

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const isArmored = r === 0 && waveNum >= 2;
        list.push({
          x: 64 + c * 74,
          y: 44 + r * 48,
          w: 56,
          h: 30,
          hp: isArmored ? 2 : 1,
          maxHp: isArmored ? 2 : 1,
          label: isArmored ? 'HEAP*2' : labels[(r + c) % labels.length],
          color: colors[(r + waveNum) % colors.length],
          points: isArmored ? 40 : 20,
        });
      }
    }
    enemiesRef.current = list;
    enemyDirRef.current = 1;
  }, []);

  const spawnBurst = (x: number, y: number, color: string, count = 14) => {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 1.2 + Math.random() * 4;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: 1,
        color,
        r: 2 + Math.random() * 2.5,
      });
    }
  };

  const resetGame = useCallback(() => {
    shipXRef.current = CANVAS_W / 2;
    lasersRef.current = [];
    powerUpsRef.current = [];
    particlesRef.current = [];
    scoreRef.current = 0;
    waveRef.current = 1;
    livesRef.current = 3;
    dualUntilRef.current = 0;
    shieldRef.current = false;
    shakeRef.current = 0;

    spawnWave(1);
    setScore(0);
    setWave(1);
    setLives(3);
    setDualFire(false);
    setHasShield(false);
    setGameState('PLAYING');
  }, [spawnWave]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        keysRef.current.left = true;
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        keysRef.current.right = true;
      } else if (e.key === ' ') {
        if (stateRef.current === 'PLAYING') e.preventDefault();
        keysRef.current.fire = true;
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        keysRef.current.left = false;
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        keysRef.current.right = false;
      } else if (e.key === ' ') {
        keysRef.current.fire = false;
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, []);

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (stateRef.current !== 'PLAYING') return;
    const rect = e.currentTarget.getBoundingClientRect();
    const scaleX = CANVAS_W / rect.width;
    const mx = (e.clientX - rect.left) * scaleX;
    shipXRef.current = Math.max(28, Math.min(CANVAS_W - 28, mx));
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const frame = (now: number) => {
      // Animate starfield continuously
      for (const s of starsRef.current) {
        s.y += s.speed;
        if (s.y > CANVAS_H) {
          s.y = 0;
          s.x = Math.random() * CANVAS_W;
        }
      }

      if (stateRef.current === 'PLAYING') {
        // Ship movement
        if (keysRef.current.left) shipXRef.current = Math.max(28, shipXRef.current - 5.5);
        if (keysRef.current.right) shipXRef.current = Math.min(CANVAS_W - 28, shipXRef.current + 5.5);

        const isDual = now < dualUntilRef.current;
        setDualFire(isDual);

        // Fire plasma bolts
        const fireCooldown = isDual ? 160 : 230;
        if ((autoFireRef.current || keysRef.current.fire) && now - lastShotRef.current > fireCooldown) {
          lastShotRef.current = now;
          arcadeAudio.shoot();
          if (isDual) {
            lasersRef.current.push(
              { x: shipXRef.current - 12, y: CANVAS_H - 52, vy: -8.5 },
              { x: shipXRef.current + 12, y: CANVAS_H - 52, vy: -8.5 }
            );
          } else {
            lasersRef.current.push({ x: shipXRef.current, y: CANVAS_H - 54, vy: -8.5 });
          }
        }

        // Move Enemies
        const enemies = enemiesRef.current;
        const speed = 1.0 + waveRef.current * 0.25;
        let hitEdge = false;
        for (const e of enemies) {
          e.x += enemyDirRef.current * speed;
          if (e.x <= 16 || e.x + e.w >= CANVAS_W - 16) hitEdge = true;
        }
        if (hitEdge) {
          enemyDirRef.current *= -1;
          for (const e of enemies) {
            e.y += 18;
          }
        }

        // Random enemy shot
        if (enemies.length > 0 && Math.random() < 0.018 + waveRef.current * 0.004) {
          const shooter = enemies[Math.floor(Math.random() * enemies.length)];
          lasersRef.current.push({
            x: shooter.x + shooter.w / 2,
            y: shooter.y + shooter.h,
            vy: 4.2 + waveRef.current * 0.3,
            isEnemy: true,
          });
        }

        // Update Lasers & Collisions
        const remainingLasers: Laser[] = [];
        for (const l of lasersRef.current) {
          l.y += l.vy;
          if (l.y < -15 || l.y > CANVAS_H + 15) continue;

          if (l.isEnemy) {
            // Check player hit
            if (
              Math.abs(l.x - shipXRef.current) < 22 &&
              Math.abs(l.y - (CANVAS_H - 36)) < 18
            ) {
              if (shieldRef.current) {
                shieldRef.current = false;
                setHasShield(false);
                arcadeAudio.pop(2);
                spawnBurst(shipXRef.current, CANVAS_H - 36, '#00F0FF', 16);
              } else {
                arcadeAudio.hit();
                shakeRef.current = 10;
                livesRef.current -= 1;
                setLives(livesRef.current);
                spawnBurst(shipXRef.current, CANVAS_H - 36, '#FF5A79', 20);
                if (livesRef.current <= 0) {
                  arcadeAudio.gameOver();
                  setGameState('GAME_OVER');
                  onScoreSubmit(scoreRef.current, Math.max(20, Math.round(scoreRef.current * 0.5)));
                }
              }
              continue;
            }
            remainingLasers.push(l);
          } else {
            // Check enemy hit
            let hit = false;
            for (let i = 0; i < enemies.length; i++) {
              const e = enemies[i];
              if (l.x >= e.x && l.x <= e.x + e.w && l.y >= e.y && l.y <= e.y + e.h) {
                hit = true;
                e.hp -= 1;
                if (e.hp <= 0) {
                  arcadeAudio.pop(waveRef.current);
                  spawnBurst(e.x + e.w / 2, e.y + e.h / 2, e.color, 16);
                  scoreRef.current += e.points;
                  setScore(scoreRef.current);

                  // Chance to drop power-up
                  if (Math.random() < 0.16) {
                    powerUpsRef.current.push({
                      x: e.x + e.w / 2,
                      y: e.y + e.h / 2,
                      kind: Math.random() < 0.6 ? 'dual' : 'shield',
                    });
                  }
                  enemies.splice(i, 1);
                } else {
                  arcadeAudio.eat();
                  spawnBurst(l.x, l.y, '#FFFFFF', 6);
                }
                break;
              }
            }
            if (!hit) remainingLasers.push(l);
          }
        }
        lasersRef.current = remainingLasers;

        // Powerups
        const nextPowers: PowerUp[] = [];
        for (const p of powerUpsRef.current) {
          p.y += 2.4;
          if (
            Math.abs(p.x - shipXRef.current) < 26 &&
            Math.abs(p.y - (CANVAS_H - 36)) < 22
          ) {
            arcadeAudio.bonus();
            if (p.kind === 'dual') {
              dualUntilRef.current = now + 7000;
              setDualFire(true);
            } else {
              shieldRef.current = true;
              setHasShield(true);
            }
            continue;
          }
          if (p.y < CANVAS_H + 20) nextPowers.push(p);
        }
        powerUpsRef.current = nextPowers;

        // Wave cleared -> Next Wave!
        if (enemies.length === 0) {
          arcadeAudio.levelUp();
          waveRef.current += 1;
          setWave(waveRef.current);
          spawnWave(waveRef.current);
        }

        // Enemies reached ship floor
        if (enemies.some((e) => e.y + e.h >= CANVAS_H - 64)) {
          arcadeAudio.gameOver();
          setGameState('GAME_OVER');
          onScoreSubmit(scoreRef.current, Math.max(20, Math.round(scoreRef.current * 0.5)));
        }
      }

      // Draw Background with optional micro screen shake
      ctx.save();
      if (shakeRef.current > 0) {
        const sx = (Math.random() - 0.5) * shakeRef.current;
        const sy = (Math.random() - 0.5) * shakeRef.current;
        ctx.translate(sx, sy);
        shakeRef.current = Math.max(0, shakeRef.current - 0.8);
      }

      ctx.fillStyle = '#080B14';
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

      // Stars
      for (const s of starsRef.current) {
        ctx.fillStyle = 'rgba(211, 251, 255, 0.55)';
        ctx.fillRect(s.x, s.y, s.size, s.size);
      }

      // Enemies
      for (const e of enemiesRef.current) {
        ctx.save();
        ctx.shadowBlur = 12;
        ctx.shadowColor = e.color;
        ctx.fillStyle = '#182035';
        ctx.strokeStyle = e.color;
        ctx.lineWidth = e.hp > 1 ? 2.5 : 1.5;
        ctx.beginPath();
        ctx.roundRect(e.x, e.y, e.w, e.h, 6);
        ctx.fill();
        ctx.stroke();

        ctx.shadowBlur = 0;
        ctx.fillStyle = e.color;
        ctx.font = '700 10px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(e.label, e.x + e.w / 2, e.y + e.h / 2);
        ctx.restore();
      }

      // Powerups
      for (const p of powerUpsRef.current) {
        ctx.save();
        const col = p.kind === 'dual' ? '#FFB800' : '#00F0FF';
        ctx.shadowBlur = 12;
        ctx.shadowColor = col;
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 11, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#080B14';
        ctx.font = '700 9px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(p.kind === 'dual' ? '2X' : 'SH', p.x, p.y + 0.5);
        ctx.restore();
      }

      // Lasers
      for (const l of lasersRef.current) {
        ctx.save();
        ctx.shadowBlur = 10;
        ctx.shadowColor = l.isEnemy ? '#FF5A79' : '#00F0FF';
        ctx.fillStyle = l.isEnemy ? '#FF5A79' : '#00F0FF';
        ctx.fillRect(l.x - 2, l.y - 7, 4, 14);
        ctx.restore();
      }

      // Player Starfighter
      const sx = shipXRef.current;
      const sy = CANVAS_H - 36;
      ctx.save();
      if (shieldRef.current) {
        ctx.strokeStyle = 'rgba(0, 240, 255, 0.75)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(sx, sy, 26, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.shadowBlur = 16;
      ctx.shadowColor = '#8A3FFC';
      ctx.fillStyle = '#00F0FF';
      ctx.beginPath();
      ctx.moveTo(sx, sy - 18);
      ctx.lineTo(sx + 20, sy + 14);
      ctx.lineTo(sx, sy + 6);
      ctx.lineTo(sx - 20, sy + 14);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#8A3FFC';
      ctx.beginPath();
      ctx.moveTo(sx, sy - 9);
      ctx.lineTo(sx + 9, sy + 8);
      ctx.lineTo(sx - 9, sy + 8);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      // Particles
      const nextParticles: Particle[] = [];
      for (const p of particlesRef.current) {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.036;
        if (p.life > 0) {
          ctx.save();
          ctx.globalAlpha = p.life;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          nextParticles.push(p);
        }
      }
      particlesRef.current = nextParticles;
      ctx.restore();

      animRef.current = requestAnimationFrame(frame);
    };

    if (enemiesRef.current.length === 0) {
      spawnWave(1);
    }
    animRef.current = requestAnimationFrame(frame);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [onScoreSubmit, spawnWave]);

  const toggleMute = () => {
    arcadeAudio.muted = !muted;
    setMuted(arcadeAudio.muted);
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      <div className="lg:col-span-8 space-y-4">
        {/* Top HUD */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#101524] px-4 py-3">
          <div className="flex items-center gap-4 font-mono text-xs sm:text-sm">
            <div>
              <span className="text-[#968DA1]">Score </span>
              <span className="font-bold text-[#00F0FF]">{score}</span>
            </div>
            <div>
              <span className="text-[#968DA1]">Wave </span>
              <span className="font-bold text-[#FFB800]">{wave}</span>
            </div>
            <div className="inline-flex items-center gap-1 text-[#FF5A79] font-bold">
              <Heart className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
              <span>{lives}</span>
            </div>
            <div className="hidden sm:block">
              <span className="text-[#968DA1]">Best </span>
              <span className="font-bold text-[#10E784]">
                {Math.max(highScore, score)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleMute}
              aria-label={muted ? 'Unmute sound effects' : 'Mute sound effects'}
              className="rounded-lg border border-white/10 bg-[#182035] p-2 text-[#CDC2D8] hover:text-[#00F0FF]"
            >
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
            {gameState === 'PLAYING' && (
              <button
                type="button"
                onClick={() => setGameState('PAUSED')}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#182035] px-3 py-1.5 text-xs font-semibold text-[#E0E2EF] hover:border-[#00F0FF]"
              >
                <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Pause</span>
              </button>
            )}
          </div>
        </div>

        {/* Canvas Arena */}
        <div className="relative overflow-hidden rounded-2xl border border-white/12 bg-[#080B14] shadow-[0_0_32px_rgba(0,240,255,0.14)]">
          <canvas
            ref={canvasRef}
            width={CANVAS_W}
            height={CANVAS_H}
            onPointerMove={handlePointerMove}
            onClick={() => {
              if (stateRef.current === 'PLAYING') {
                keysRef.current.fire = true;
                setTimeout(() => {
                  keysRef.current.fire = false;
                }, 100);
              }
            }}
            className="block w-full h-auto cursor-crosshair touch-none aspect-[640/460]"
          />

          {/* TITLE MENU */}
          {gameState === 'TITLE_MENU' && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#080B14]/85 backdrop-blur-sm p-4">
              <div className="w-full max-w-md overflow-hidden rounded-2xl border border-white/15 bg-[#101524] shadow-2xl">
                <div className="relative h-40 w-full overflow-hidden">
                  <ArtworkImage
                    src="/src/assets/images/game_cover_blaster_1794820233826.jpg"
                    alt="Malloc Blaster starfighter artwork"
                    className="h-full w-full object-cover"
                    fallbackTitle="Malloc Blaster"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101524] via-[#101524]/40 to-transparent" />
                </div>
                <div className="p-5 space-y-4">
                  <div>
                    <h2 className="font-display text-2xl font-bold text-[#E0E2EF]">
                      Malloc Blaster
                    </h2>
                    <p className="mt-1 text-sm text-[#CDC2D8]">
                      Slide with Mouse, Touch, or Arrow Keys to blast descending memory-leak invaders and catch 2X laser &amp; Shield cores!
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={resetGame}
                    className="btn-arcade-primary w-full inline-flex items-center justify-center gap-2 rounded-lg px-5 py-3 text-sm font-semibold"
                  >
                    <Play className="h-4 w-4" aria-hidden="true" />
                    <span>Launch Starfighter</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* PAUSED */}
          {gameState === 'PAUSED' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-[#080B14]/80 backdrop-blur-sm p-6">
              <h2 className="font-display text-3xl font-bold text-[#E0E2EF]">
                Paused
              </h2>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setGameState('PLAYING')}
                  className="btn-arcade-primary inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold"
                >
                  <Play className="h-4 w-4" aria-hidden="true" />
                  <span>Resume</span>
                </button>
                <button
                  type="button"
                  onClick={resetGame}
                  className="btn-arcade-secondary inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  <span>Restart</span>
                </button>
              </div>
            </div>
          )}

          {/* GAME OVER */}
          {gameState === 'GAME_OVER' && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#080B14]/85 backdrop-blur-sm p-4">
              <div className="w-full max-w-sm rounded-2xl border border-[#FF5A79]/45 bg-[#101524] p-6 text-center space-y-4">
                <div className="font-mono text-xs font-bold text-[#FFB4AB]">
                  MEMORY BREACHED · WAVE {wave}
                </div>
                <h2 className="font-display text-2xl font-bold text-[#E0E2EF]">
                  Game Over
                </h2>
                <div className="rounded-xl border border-white/10 bg-[#182035] p-3 font-mono">
                  <div className="text-[11px] text-[#968DA1]">Final Score</div>
                  <div className="text-2xl font-bold text-[#00F0FF]">{score}</div>
                </div>
                <button
                  type="button"
                  onClick={resetGame}
                  className="btn-arcade-primary w-full inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  <span>Play Again</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right: Ship Upgrades & Blaster Status */}
      <aside className="lg:col-span-4 space-y-5">
        <section className="rounded-2xl border border-white/10 bg-[#182035] p-5 space-y-4">
          <h3 className="font-display text-base font-semibold text-[#E0E2EF]">
            Ship Systems
          </h3>

          <div className="space-y-2.5 font-mono text-xs">
            <div
              className={`flex items-center justify-between rounded-lg border px-3.5 py-2.5 ${
                dualFire
                  ? 'border-[#FFB800] bg-[#FFB800]/15 text-[#FFB800]'
                  : 'border-white/10 bg-[#101524] text-[#968DA1]'
              }`}
            >
              <span className="inline-flex items-center gap-2 font-semibold">
                <Zap className="h-4 w-4" aria-hidden="true" />
                2X Twin Laser
              </span>
              <span>{dualFire ? 'ACTIVE' : 'OFFLINE'}</span>
            </div>

            <div
              className={`flex items-center justify-between rounded-lg border px-3.5 py-2.5 ${
                hasShield
                  ? 'border-[#00F0FF] bg-[#00F0FF]/15 text-[#00F0FF]'
                  : 'border-white/10 bg-[#101524] text-[#968DA1]'
              }`}
            >
              <span className="inline-flex items-center gap-2 font-semibold">
                <Shield className="h-4 w-4" aria-hidden="true" />
                Pointer Shield
              </span>
              <span>{hasShield ? 'ARMED' : 'EMPTY'}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setAutoFire((v) => !v)}
            className={`w-full rounded-lg border px-4 py-2 text-xs font-semibold transition-colors ${
              autoFire
                ? 'border-[#10E784]/50 bg-[#10E784]/15 text-[#10E784]'
                : 'border-white/12 bg-[#101524] text-[#CDC2D8]'
            }`}
          >
            Auto-Fire: {autoFire ? 'ON' : 'OFF (Press Space)'}
          </button>
        </section>

        <section className="rounded-2xl border border-white/10 bg-[#101524] p-5 space-y-2.5">
          <h3 className="font-display text-base font-semibold text-[#E0E2EF]">
            How It Works in C
          </h3>
          <p className="text-xs sm:text-sm text-[#CDC2D8] leading-relaxed">
            Every laser bolt runs a <code className="text-[#00F0FF]">free(enemy)</code> cleanup routine before uninitialized <code className="text-[#FFB4AB]">LEAK</code> and <code className="text-[#FFB800]">NULL</code> cubes reach your stack frame.
          </p>
        </section>
      </aside>
    </div>
  );
};
