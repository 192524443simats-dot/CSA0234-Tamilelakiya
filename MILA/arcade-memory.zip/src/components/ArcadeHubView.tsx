import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Cpu, Download, Play, Trophy } from 'lucide-react';
import { AppView } from '../types/memory';
import { ArtworkImage } from './ArtworkImage';

interface ArcadeHubViewProps {
  xp: number;
  highScores: {
    snake: number;
    bubble: number;
    blaster: number;
  };
  onLaunchGame: (view: AppView) => void;
  onDownloadStartBat: () => void;
}

const GAMES: {
  id: 'snake' | 'bubble' | 'blaster';
  title: string;
  cTag: string;
  accentBar: string;
  accentText: string;
  description: string;
  image: string;
  alt: string;
  controls: string;
}[] = [
  {
    id: 'snake',
    title: 'Byte Snake',
    cTag: 'Linked List · snake.c',
    accentBar: 'bg-[#00F0FF]',
    accentText: 'text-[#00F0FF]',
    description:
      'Glide across the circuit grid eating glowing int, char, float, and *ptr orbs to grow your linked-list tail in real time.',
    image: '/src/assets/images/game_cover_snake_1794820232099.jpg',
    alt: 'Byte Snake glowing neon serpent eating golden energy orb',
    controls: 'Arrows / WASD / D-Pad',
  },
  {
    id: 'bubble',
    title: 'Pointer Bubble Shooter',
    cTag: 'Flood Fill · bubble.c',
    accentBar: 'bg-[#8A3FFC]',
    accentText: 'text-[#D4BBFF]',
    description:
      'Bounce neon C-type orbs off arena walls, match 3+ to pop clusters, and trigger free() bomb cascades for massive combos.',
    image: '/src/assets/images/game_cover_bubble_1794820232436.jpg',
    alt: 'Pointer Bubble Shooter glowing orb cluster and laser cannon',
    controls: 'Mouse / Touch Aim + Click',
  },
  {
    id: 'blaster',
    title: 'Malloc Blaster',
    cTag: 'Heap Defense · blaster.c',
    accentBar: 'bg-[#FFB800]',
    accentText: 'text-[#FFB800]',
    description:
      'Pilot a cyber starfighter firing free() plasma lasers at descending LEAK & NULL invaders while grabbing 2X & Shield cores.',
    image: '/src/assets/images/game_cover_blaster_1794820233826.jpg',
    alt: 'Malloc Blaster starfighter firing plasma at neon cubes',
    controls: 'Mouse / Arrows + Auto-Fire',
  },
];

export const ArcadeHubView: React.FC<ArcadeHubViewProps> = ({
  xp,
  highScores,
  onLaunchGame,
  onDownloadStartBat,
}) => {
  const totalScore = highScores.snake + highScores.bubble + highScores.blaster;
  const level = Math.floor(xp / 250) + 1;

  return (
    <div className="space-y-8">
      {/* Illustrated Cyber-Arcade Hero Banner */}
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
        className="relative overflow-hidden rounded-2xl border border-white/12 bg-[#101524]"
      >
        {/* Background Artwork + Measured Contrast Scrim */}
        <div className="absolute inset-0">
          <ArtworkImage
            src="/src/assets/images/arcade_hero_banner_1794820231961.jpg"
            alt="Arcade Memory Matrix arena backdrop"
            className="h-full w-full object-cover opacity-55"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#080B14] via-[#080B14]/88 to-[#080B14]/55" />
        </div>

        <div className="relative z-10 grid grid-cols-1 gap-8 p-6 sm:p-9 lg:grid-cols-12 lg:items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="flex flex-wrap items-center gap-2 font-mono text-xs text-[#00F0FF]">
              <span>Level {level} Arcade Player</span>
              <span aria-hidden="true" className="text-[#4B4455]">·</span>
              <span className="text-[#FFB800]">{xp.toLocaleString()} XP</span>
              <span aria-hidden="true" className="text-[#4B4455]">·</span>
              <span className="text-[#10E784]">60fps Real-Time C Games</span>
            </div>

            <h1 className="font-display text-3xl sm:text-4xl lg:text-[44px] font-bold tracking-tight text-[#E0E2EF] leading-[1.1] [text-wrap:balance]">
              Play real-time C arcade games with live memory physics.
            </h1>

            <p className="max-w-xl text-[15px] sm:text-base text-[#CDC2D8] leading-relaxed">
              Jump straight into animated 60fps games—slither through linked lists in Byte Snake, bounce shots in Pointer Bubble Shooter, and defend the heap in Malloc Blaster.
            </p>

            <div className="flex flex-wrap items-center gap-3.5 pt-1">
              <button
                type="button"
                onClick={() => onLaunchGame('snake')}
                className="btn-arcade-primary inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold whitespace-nowrap"
              >
                <Play className="h-4 w-4" aria-hidden="true" />
                <span>Play Byte Snake</span>
              </button>

              <button
                type="button"
                onClick={() => onLaunchGame('bubble')}
                className="btn-arcade-secondary inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold whitespace-nowrap"
              >
                <span>Play Bubble Shooter</span>
              </button>
            </div>
          </div>

          {/* Right Arcade High-Score Cabinet Card */}
          <div className="lg:col-span-5 rounded-xl border border-white/12 bg-[#101524]/90 backdrop-blur-md p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#FFB800]/15 border border-[#FFB800]/40 text-[#FFB800]">
                  <Trophy className="h-5 w-5" aria-hidden="true" />
                </div>
                <div>
                  <div className="font-mono text-[11px] text-[#968DA1]">
                    Combined Arcade Score
                  </div>
                  <div className="font-mono text-2xl font-bold text-[#FFB800]">
                    {totalScore.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2.5 border-t border-white/10 pt-4 font-mono">
              <div className="rounded-lg bg-[#182035] p-2.5">
                <div className="text-[11px] text-[#968DA1]">Snake</div>
                <div className="text-base font-bold text-[#00F0FF]">
                  {highScores.snake}
                </div>
              </div>
              <div className="rounded-lg bg-[#182035] p-2.5">
                <div className="text-[11px] text-[#968DA1]">Bubbles</div>
                <div className="text-base font-bold text-[#D4BBFF]">
                  {highScores.bubble}
                </div>
              </div>
              <div className="rounded-lg bg-[#182035] p-2.5">
                <div className="text-[11px] text-[#968DA1]">Blaster</div>
                <div className="text-base font-bold text-[#FFB800]">
                  {highScores.blaster}
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* 3 Real-Time Illustrated Game Cards */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold text-[#E0E2EF]">
              Featured C Arcade Cabinets
            </h2>
            <p className="text-sm text-[#968DA1]">
              Pick any game below to start playing immediately with sound effects and live score tracking.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {GAMES.map((game, idx) => (
            <motion.article
              key={game.id}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.25,
                delay: idx * 0.06,
                ease: [0.16, 1, 0.3, 1],
              }}
              whileHover={{ y: -4 }}
              className="group flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#182035] transition-colors hover:border-[#00F0FF]/50"
            >
              <div className={`h-1 w-full ${game.accentBar}`} aria-hidden="true" />

              {/* Game Cover Art */}
              <div className="relative aspect-video w-full overflow-hidden bg-[#0A0E1A]">
                <ArtworkImage
                  src={game.image}
                  alt={game.alt}
                  fallbackTitle={game.title}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#182035] via-transparent to-transparent" />
              </div>

              <div className="flex flex-1 flex-col justify-between p-5 space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between font-mono text-xs">
                    <span className={game.accentText}>{game.cTag}</span>
                    <span className="text-[#FFB800] font-semibold">
                      Best: {highScores[game.id]}
                    </span>
                  </div>

                  <h3 className="font-display text-xl font-bold text-[#E0E2EF]">
                    {game.title}
                  </h3>

                  <p className="text-sm text-[#CDC2D8] leading-relaxed">
                    {game.description}
                  </p>
                </div>

                <div className="space-y-3 pt-1">
                  <div className="font-mono text-xs text-[#968DA1]">
                    Controls: {game.controls}
                  </div>
                  <button
                    type="button"
                    onClick={() => onLaunchGame(game.id)}
                    className="btn-arcade-primary w-full inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold"
                  >
                    <Play className="h-4 w-4" aria-hidden="true" />
                    <span>Play {game.title}</span>
                  </button>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      {/* Bottom Utility Strip: Memory Visualizer Lab + Local start.bat Launcher */}
      <section className="grid grid-cols-1 gap-5 md:grid-cols-2">
        <div className="flex flex-col justify-between gap-4 rounded-2xl border border-white/8 bg-[#101524] p-5 sm:flex-row sm:items-center">
          <div className="space-y-1">
            <div className="flex items-center gap-2 font-mono text-xs text-[#D4BBFF]">
              <Cpu className="h-4 w-4" aria-hidden="true" />
              <span>Interactive C Code Visualizer</span>
            </div>
            <h3 className="font-display text-lg font-semibold text-[#E0E2EF]">
              Memory &amp; Pointer Lab
            </h3>
            <p className="text-xs sm:text-sm text-[#968DA1]">
              Step through stack frames, pointer beams, and malloc/free challenges anytime.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onLaunchGame('lab')}
            className="btn-arcade-secondary inline-flex items-center justify-center gap-1.5 rounded-lg px-4 py-2.5 text-xs font-semibold whitespace-nowrap shrink-0"
          >
            <span>Open Lab</span>
            <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>

        <div className="flex flex-col justify-between gap-4 rounded-2xl border border-white/8 bg-[#101524] p-5 sm:flex-row sm:items-center">
          <div className="space-y-1">
            <div className="font-mono text-xs text-[#10E784]">
              Windows Local Launcher Included
            </div>
            <h3 className="font-display text-lg font-semibold text-[#E0E2EF]">
              start.bat Ready
            </h3>
            <p className="text-xs sm:text-sm text-[#968DA1]">
              Included in the project root zip, or download a copy of start.bat directly here.
            </p>
          </div>
          <button
            type="button"
            onClick={onDownloadStartBat}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-white/15 bg-[#182035] px-4 py-2.5 text-xs font-semibold text-[#E0E2EF] hover:border-[#00F0FF] hover:text-[#00F0FF] transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Download start.bat</span>
          </button>
        </div>
      </section>
    </div>
  );
};
