import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Pause,
  Play,
  RotateCcw,
  Trophy,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { GameState } from '../types/memory';
import { arcadeAudio } from '../utils/arcadeAudio';
import { ArtworkImage } from './ArtworkImage';

interface ByteSnakeGameProps {
  highScore: number;
  onScoreSubmit: (score: number, xpGain: number) => void;
}

interface Point {
  x: number;
  y: number;
}

interface FoodItem {
  x: number;
  y: number;
  kind: 'int' | 'char' | 'float' | 'ptr';
  color: string;
  points: number;
  label: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  radius: number;
}

const COLS = 24;
const ROWS = 16;
const CELL = 26;
const CANVAS_W = COLS * CELL; // 624
const CANVAS_H = ROWS * CELL; // 416

const FOOD_TYPES: Omit<FoodItem, 'x' | 'y'>[] = [
  { kind: 'int', color: '#00F0FF', points: 15, label: 'int' },
  { kind: 'char', color: '#D4BBFF', points: 20, label: 'char' },
  { kind: 'float', color: '#10E784', points: 25, label: 'float' },
  { kind: 'ptr', color: '#FFB800', points: 50, label: '*ptr' },
];

export const ByteSnakeGame: React.FC<ByteSnakeGameProps> = ({
  highScore,
  onScoreSubmit,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [gameState, setGameState] = useState<GameState>('TITLE_MENU');
  const [score, setScore] = useState(0);
  const [length, setLength] = useState(4);
  const [speedLevel, setSpeedLevel] = useState(1);
  const [lastType, setLastType] = useState<string>('struct Node');
  const [muted, setMuted] = useState(arcadeAudio.muted);

  const snakeRef = useRef<Point[]>([
    { x: 8, y: 8 },
    { x: 7, y: 8 },
    { x: 6, y: 8 },
    { x: 5, y: 8 },
  ]);
  const dirRef = useRef<Point>({ x: 1, y: 0 });
  const nextDirRef = useRef<Point>({ x: 1, y: 0 });
  const foodRef = useRef<FoodItem>({ x: 16, y: 8, ...FOOD_TYPES[0] });
  const particlesRef = useRef<Particle[]>([]);
  const scoreRef = useRef(0);
  const lastStepTimeRef = useRef(0);
  const stepProgressRef = useRef(1);
  const animFrameRef = useRef<number | null>(null);
  const stateRef = useRef<GameState>('TITLE_MENU');

  useEffect(() => {
    stateRef.current = gameState;
  }, [gameState]);

  const spawnFood = useCallback((snake: Point[]): FoodItem => {
    let fx = 0;
    let fy = 0;
    let tries = 0;
    do {
      fx = Math.floor(Math.random() * COLS);
      fy = Math.floor(Math.random() * ROWS);
      tries++;
    } while (
      snake.some((seg) => seg.x === fx && seg.y === fy) &&
      tries < 150
    );

    const roll = Math.random();
    const spec =
      roll > 0.82
        ? FOOD_TYPES[3]
        : roll > 0.55
        ? FOOD_TYPES[2]
        : roll > 0.28
        ? FOOD_TYPES[1]
        : FOOD_TYPES[0];

    return { x: fx, y: fy, ...spec };
  }, []);

  const spawnBurst = (cx: number, cy: number, color: string, count = 16) => {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.4;
      const speed = 1.4 + Math.random() * 3.2;
      particlesRef.current.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1,
        maxLife: 1,
        color,
        radius: 2 + Math.random() * 2.5,
      });
    }
  };

  const resetGame = useCallback(() => {
    const startSnake: Point[] = [
      { x: 8, y: 8 },
      { x: 7, y: 8 },
      { x: 6, y: 8 },
      { x: 5, y: 8 },
    ];
    snakeRef.current = startSnake;
    dirRef.current = { x: 1, y: 0 };
    nextDirRef.current = { x: 1, y: 0 };
    foodRef.current = spawnFood(startSnake);
    particlesRef.current = [];
    scoreRef.current = 0;
    setScore(0);
    setLength(startSnake.length);
    setSpeedLevel(1);
    setLastType('struct Node');
    lastStepTimeRef.current = performance.now();
    stepProgressRef.current = 1;
    setGameState('PLAYING');
  }, [spawnFood]);

  const setDirection = useCallback((dx: number, dy: number) => {
    const cur = dirRef.current;
    if (cur.x === -dx && cur.y === -dy) return;
    nextDirRef.current = { x: dx, y: dy };
  }, []);

  // Keyboard bindings
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (stateRef.current !== 'PLAYING') {
        if (e.key === ' ' && stateRef.current === 'PAUSED') {
          e.preventDefault();
          setGameState('PLAYING');
        }
        return;
      }

      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
        e.preventDefault();
      }

      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') setDirection(0, -1);
      else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') setDirection(0, 1);
      else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') setDirection(-1, 0);
      else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') setDirection(1, 0);
      else if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') setGameState('PAUSED');
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [setDirection]);

  // 60fps Canvas Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const renderFrame = (now: number) => {
      const level = Math.min(8, 1 + Math.floor(scoreRef.current / 90));
      const tickMs = Math.max(72, 148 - (level - 1) * 10);

      if (stateRef.current === 'PLAYING') {
        if (!lastStepTimeRef.current) lastStepTimeRef.current = now;
        const elapsed = now - lastStepTimeRef.current;
        stepProgressRef.current = Math.min(1, elapsed / tickMs);

        if (elapsed >= tickMs) {
          lastStepTimeRef.current = now;
          dirRef.current = nextDirRef.current;

          const snake = snakeRef.current;
          const head = snake[0];
          const nx = head.x + dirRef.current.x;
          const ny = head.y + dirRef.current.y;

          const hitWall = nx < 0 || nx >= COLS || ny < 0 || ny >= ROWS;
          const hitSelf = snake.some((seg) => seg.x === nx && seg.y === ny);

          if (hitWall || hitSelf) {
            arcadeAudio.gameOver();
            spawnBurst(
              head.x * CELL + CELL / 2,
              head.y * CELL + CELL / 2,
              '#FF5A79',
              28
            );
            setGameState('GAME_OVER');
            onScoreSubmit(scoreRef.current, Math.max(15, Math.round(scoreRef.current * 0.6)));
          } else {
            const newHead = { x: nx, y: ny };
            const food = foodRef.current;
            const ate = nx === food.x && ny === food.y;

            const nextSnake = ate
              ? [newHead, ...snake]
              : [newHead, ...snake.slice(0, -1)];
            snakeRef.current = nextSnake;

            if (ate) {
              if (food.kind === 'ptr') arcadeAudio.bonus();
              else arcadeAudio.eat();

              spawnBurst(
                food.x * CELL + CELL / 2,
                food.y * CELL + CELL / 2,
                food.color,
                20
              );

              scoreRef.current += food.points;
              setScore(scoreRef.current);
              setLength(nextSnake.length);
              setSpeedLevel(Math.min(8, 1 + Math.floor(scoreRef.current / 90)));
              setLastType(`${food.label} (+${food.points})`);
              foodRef.current = spawnFood(nextSnake);
            }
          }
        }
      }

      // Draw Background
      ctx.fillStyle = '#080B14';
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

      // Subtle Neon Circuit Grid
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.06)';
      ctx.lineWidth = 1;
      for (let x = 0; x <= COLS; x++) {
        ctx.beginPath();
        ctx.moveTo(x * CELL, 0);
        ctx.lineTo(x * CELL, CANVAS_H);
        ctx.stroke();
      }
      for (let y = 0; y <= ROWS; y++) {
        ctx.beginPath();
        ctx.moveTo(0, y * CELL);
        ctx.lineTo(CANVAS_W, y * CELL);
        ctx.stroke();
      }

      // Draw Food Orb with pulse
      const food = foodRef.current;
      const pulse = 1 + Math.sin(now * 0.008) * 0.14;
      const fcx = food.x * CELL + CELL / 2;
      const fcy = food.y * CELL + CELL / 2;

      ctx.save();
      ctx.shadowBlur = 18;
      ctx.shadowColor = food.color;
      ctx.fillStyle = food.color;
      ctx.beginPath();
      ctx.arc(fcx, fcy, (CELL * 0.34) * pulse, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#080B14';
      ctx.font = '700 9px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowBlur = 0;
      ctx.fillText(food.label, fcx, fcy + 0.5);
      ctx.restore();

      // Draw Snake Linked-List Nodes
      const snake = snakeRef.current;
      for (let i = snake.length - 1; i >= 0; i--) {
        const seg = snake[i];
        const cx = seg.x * CELL + CELL / 2;
        const cy = seg.y * CELL + CELL / 2;
        const isHead = i === 0;

        // Pointer beam connecting to previous segment
        if (i < snake.length - 1) {
          const nextSeg = snake[i + 1];
          ctx.strokeStyle = 'rgba(0, 240, 255, 0.35)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.lineTo(nextSeg.x * CELL + CELL / 2, nextSeg.y * CELL + CELL / 2);
          ctx.stroke();
        }

        ctx.save();
        const pad = isHead ? 2 : 3.5;
        const size = CELL - pad * 2;
        const rx = seg.x * CELL + pad;
        const ry = seg.y * CELL + pad;

        if (isHead) {
          ctx.shadowBlur = 16;
          ctx.shadowColor = '#00F0FF';
          ctx.fillStyle = '#00F0FF';
        } else {
          const ratio = 1 - i / Math.max(snake.length, 1);
          ctx.fillStyle = i % 2 === 0 ? '#8A3FFC' : `rgba(0, 240, 255, ${0.35 + ratio * 0.45})`;
        }

        ctx.beginPath();
        ctx.roundRect(rx, ry, size, size, isHead ? 7 : 5);
        ctx.fill();

        if (isHead) {
          // Cute glowing arcade eyes aligned with direction
          ctx.shadowBlur = 0;
          ctx.fillStyle = '#080B14';
          const exOffset = dirRef.current.x * 4;
          const eyOffset = dirRef.current.y * 4;
          ctx.beginPath();
          ctx.arc(cx - 3 + exOffset, cy - 3 + eyOffset, 2.1, 0, Math.PI * 2);
          ctx.arc(cx + 3 + exOffset, cy + 3 + eyOffset, 2.1, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // Draw & Update Particles
      const nextParticles: Particle[] = [];
      for (const p of particlesRef.current) {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.032;
        if (p.life > 0) {
          ctx.save();
          ctx.globalAlpha = p.life;
          ctx.fillStyle = p.color;
          ctx.shadowBlur = 8;
          ctx.shadowColor = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius * p.life, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          nextParticles.push(p);
        }
      }
      particlesRef.current = nextParticles;

      animFrameRef.current = requestAnimationFrame(renderFrame);
    };

    animFrameRef.current = requestAnimationFrame(renderFrame);
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [onScoreSubmit, spawnFood]);

  const toggleMute = () => {
    arcadeAudio.muted = !muted;
    setMuted(arcadeAudio.muted);
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Left: Real-Time Game Canvas Stage */}
      <div className="lg:col-span-8 space-y-4">
        {/* Top Unobstructed Game HUD */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#101524] px-4 py-3">
          <div className="flex items-center gap-4 font-mono text-xs sm:text-sm">
            <div>
              <span className="text-[#968DA1]">Score </span>
              <span className="font-bold text-[#00F0FF]">{score}</span>
            </div>
            <div>
              <span className="text-[#968DA1]">Nodes </span>
              <span className="font-bold text-[#D4BBFF]">{length}</span>
            </div>
            <div>
              <span className="text-[#968DA1]">Speed </span>
              <span className="font-bold text-[#FFB800]">Lv.{speedLevel}</span>
            </div>
            <div className="hidden sm:block">
              <span className="text-[#968DA1]">Best </span>
              <span className="font-bold text-[#10E784]">
                {Math.max(highScore, score)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleMute}
              aria-label={muted ? 'Unmute sound effects' : 'Mute sound effects'}
              className="rounded-lg border border-white/10 bg-[#182035] p-2 text-[#CDC2D8] hover:text-[#00F0FF] transition-colors"
            >
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>

            {gameState === 'PLAYING' && (
              <button
                type="button"
                onClick={() => setGameState('PAUSED')}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#182035] px-3 py-1.5 text-xs font-semibold text-[#E0E2EF] hover:border-[#00F0FF]"
              >
                <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Pause</span>
              </button>
            )}

            {gameState === 'PAUSED' && (
              <button
                type="button"
                onClick={() => {
                  lastStepTimeRef.current = performance.now();
                  setGameState('PLAYING');
                }}
                className="btn-arcade-primary inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold"
              >
                <Play className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Resume</span>
              </button>
            )}
          </div>
        </div>

        {/* Canvas Container */}
        <div className="relative overflow-hidden rounded-2xl border border-white/12 bg-[#080B14] shadow-[0_0_30px_rgba(0,240,255,0.12)]">
          <canvas
            ref={canvasRef}
            width={CANVAS_W}
            height={CANVAS_H}
            className="block w-full h-auto aspect-[24/16]"
          />

          {/* TITLE MENU OVERLAY */}
          {gameState === 'TITLE_MENU' && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#080B14]/85 backdrop-blur-sm p-4">
              <div className="w-full max-w-md overflow-hidden rounded-2xl border border-white/15 bg-[#101524] shadow-2xl">
                <div className="relative h-40 w-full overflow-hidden">
                  <ArtworkImage
                    src="/src/assets/images/game_cover_snake_1794820232099.jpg"
                    alt="Byte Snake arcade cover artwork"
                    className="h-full w-full object-cover"
                    fallbackTitle="Byte Snake"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101524] via-[#101524]/40 to-transparent" />
                </div>

                <div className="p-5 space-y-4">
                  <div>
                    <h2 className="font-display text-2xl font-bold text-[#E0E2EF]">
                      Byte Snake
                    </h2>
                    <p className="mt-1 text-sm text-[#CDC2D8]">
                      Steer with Arrow Keys or WASD. Eat glowing C data orbs to grow your linked-list tail without hitting a wall!
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={resetGame}
                    className="btn-arcade-primary w-full inline-flex items-center justify-center gap-2 rounded-lg px-5 py-3 text-sm font-semibold"
                  >
                    <Play className="h-4 w-4" aria-hidden="true" />
                    <span>Start Game</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* PAUSED OVERLAY */}
          {gameState === 'PAUSED' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-[#080B14]/80 backdrop-blur-sm p-6">
              <h2 className="font-display text-3xl font-bold text-[#E0E2EF]">
                Paused
              </h2>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    lastStepTimeRef.current = performance.now();
                    setGameState('PLAYING');
                  }}
                  className="btn-arcade-primary inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold"
                >
                  <Play className="h-4 w-4" aria-hidden="true" />
                  <span>Resume</span>
                </button>
                <button
                  type="button"
                  onClick={resetGame}
                  className="btn-arcade-secondary inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  <span>Restart</span>
                </button>
              </div>
            </div>
          )}

          {/* GAME OVER OVERLAY */}
          {gameState === 'GAME_OVER' && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#080B14]/85 backdrop-blur-sm p-4">
              <div className="w-full max-w-sm rounded-2xl border border-[#FF5A79]/45 bg-[#101524] p-6 text-center space-y-4">
                <div className="font-mono text-xs font-bold text-[#FFB4AB]">
                  SIGSEGV · COLLISION DETECTED
                </div>
                <h2 className="font-display text-2xl font-bold text-[#E0E2EF]">
                  Game Over
                </h2>
                <div className="grid grid-cols-2 gap-3 rounded-xl border border-white/10 bg-[#182035] p-3 font-mono">
                  <div>
                    <div className="text-[11px] text-[#968DA1]">Score</div>
                    <div className="text-xl font-bold text-[#00F0FF]">{score}</div>
                  </div>
                  <div>
                    <div className="text-[11px] text-[#968DA1]">Nodes Built</div>
                    <div className="text-xl font-bold text-[#FFB800]">{length}</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={resetGame}
                  className="btn-arcade-primary w-full inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  <span>Play Again</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right: Touch D-Pad + Live C Linked-List Inspector */}
      <aside className="lg:col-span-4 space-y-5">
        <section className="rounded-2xl border border-white/10 bg-[#182035] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-semibold text-[#E0E2EF]">
              Arcade Controls
            </h3>
            <span className="font-mono text-xs text-[#968DA1]">
              WASD / Arrows
            </span>
          </div>

          {/* Tactile D-Pad for Mouse / Touch */}
          <div className="mx-auto grid w-44 grid-cols-3 gap-2">
            <div />
            <button
              type="button"
              aria-label="Move Up"
              onClick={() => setDirection(0, -1)}
              className="flex h-12 items-center justify-center rounded-lg border border-white/15 bg-[#101524] text-[#00F0FF] hover:bg-[#222D4A] active:scale-95 transition"
            >
              <ArrowUp className="h-5 w-5" />
            </button>
            <div />
            <button
              type="button"
              aria-label="Move Left"
              onClick={() => setDirection(-1, 0)}
              className="flex h-12 items-center justify-center rounded-lg border border-white/15 bg-[#101524] text-[#00F0FF] hover:bg-[#222D4A] active:scale-95 transition"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              aria-label="Move Down"
              onClick={() => setDirection(0, 1)}
              className="flex h-12 items-center justify-center rounded-lg border border-white/15 bg-[#101524] text-[#00F0FF] hover:bg-[#222D4A] active:scale-95 transition"
            >
              <ArrowDown className="h-5 w-5" />
            </button>
            <button
              type="button"
              aria-label="Move Right"
              onClick={() => setDirection(1, 0)}
              className="flex h-12 items-center justify-center rounded-lg border border-white/15 bg-[#101524] text-[#00F0FF] hover:bg-[#222D4A] active:scale-95 transition"
            >
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </section>

        {/* Live C Struct Mirror */}
        <section className="rounded-2xl border border-white/10 bg-[#101524] p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-semibold text-[#E0E2EF]">
              Live C Linked List
            </h3>
            <span className="inline-flex items-center gap-1 font-mono text-xs text-[#FFB800]">
              <Trophy className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{lastType}</span>
            </span>
          </div>

          <pre className="rounded-xl border border-white/8 bg-[#0A0E1A] p-3.5 font-mono text-xs leading-6 text-[#D3FBFF] overflow-x-auto">
{`struct Node {
  int value;
  struct Node *next;
};

// Active chain: ${length} nodes
// Head @ 0x7FFE00 -> ${length * 8}B heap`}
          </pre>

          <div className="grid grid-cols-2 gap-2 font-mono text-xs">
            <div className="rounded-lg border border-white/8 bg-[#182035] px-3 py-2">
              <span className="text-[#00F0FF] font-bold">int</span> · +15 pts
            </div>
            <div className="rounded-lg border border-white/8 bg-[#182035] px-3 py-2">
              <span className="text-[#D4BBFF] font-bold">char</span> · +20 pts
            </div>
            <div className="rounded-lg border border-white/8 bg-[#182035] px-3 py-2">
              <span className="text-[#10E784] font-bold">float</span> · +25 pts
            </div>
            <div className="rounded-lg border border-white/8 bg-[#182035] px-3 py-2">
              <span className="text-[#FFB800] font-bold">*ptr</span> · +50 pts
            </div>
          </div>
        </section>
      </aside>
    </div>
  );
};
