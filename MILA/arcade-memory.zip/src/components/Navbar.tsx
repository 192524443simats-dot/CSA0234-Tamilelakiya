import React from 'react';
import { AppView } from '../types/memory';

interface NavbarProps {
  activeView: AppView;
  onNavigate: (view: AppView) => void;
  onQuickPlay: () => void;
}

const NAV_ITEMS: { id: AppView; label: string }[] = [
  { id: 'arcade', label: 'Arcade Hub' },
  { id: 'snake', label: 'Byte Snake' },
  { id: 'bubble', label: 'Bubble Shooter' },
  { id: 'blaster', label: 'Malloc Blaster' },
];

export const Navbar: React.FC<NavbarProps> = ({
  activeView,
  onNavigate,
  onQuickPlay,
}) => {
  return (
    <header className="sticky top-0 z-40 border-b border-white/8 bg-[#101524]/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1280px] items-center justify-between gap-8 px-4 py-3.5 sm:px-6 lg:px-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('arcade')}
          className="font-display text-lg font-bold tracking-tight text-[#E0E2EF] whitespace-nowrap shrink-0 hover:text-[#00F0FF] transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#00F0FF] rounded"
        >
          Arcade Memory Matrix
        </button>

        {/* Zone 2: 4 Single-line Game Navigation Links */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-7"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`relative py-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#00F0FF] rounded ${
                  isActive
                    ? 'text-[#00F0FF]'
                    : 'text-[#CDC2D8] hover:text-[#E0E2EF]'
                }`}
              >
                {item.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-[15px] h-[2px] bg-[#00F0FF] shadow-[0_0_10px_rgba(0,240,255,0.65)]"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary CTA */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onQuickPlay}
            className="btn-arcade-primary rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#00F0FF]"
          >
            Play Arcade
          </button>
        </div>
      </div>

      {/* Mobile Navigation Row */}
      <nav
        aria-label="Mobile navigation"
        className="flex md:hidden items-center justify-around border-t border-white/8 bg-[#0B0E17] px-2 py-1.5"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`min-h-[38px] rounded-md px-2 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                isActive
                  ? 'bg-[#182035] text-[#00F0FF]'
                  : 'text-[#968DA1] hover:text-[#E0E2EF]'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
