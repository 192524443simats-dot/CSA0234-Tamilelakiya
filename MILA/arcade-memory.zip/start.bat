@echo off
title Arcade Memory Matrix - Local Launcher
echo ============================================
echo   Starting Arcade Memory Matrix...
echo ============================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Node.js is not installed. Please install Node.js 18+ from https://nodejs.org/
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo Installing dependencies...
  call npm install
  if %errorlevel% neq 0 (
    echo [ERROR] npm install failed.
    pause
    exit /b 1
  )
)

echo Launching dev server on http://localhost:3000 ...
start "" http://localhost:3000
call npm run dev
pause
